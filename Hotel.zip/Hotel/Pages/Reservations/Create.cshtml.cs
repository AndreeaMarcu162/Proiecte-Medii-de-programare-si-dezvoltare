﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Hotel.Data;
using Hotel.Models;

namespace Hotel.Pages.Reservations
{
    public class CreateModel : ReservationFacilitiesPageModel
    {
        private readonly HotelContext _context;

        public CreateModel(HotelContext context)
        {
            _context = context;
        }

        // Proprietatea AssignedFacilityDataList
        public List<AssignedFacilityData> AssignedFacilityDataList { get; set; } = new List<AssignedFacilityData>();

        public IActionResult OnGet()
        {
            ViewData["GuestId"] = new SelectList(_context.Guest, "GuestId", "GuestId");
            ViewData["RoomId"] = new SelectList(_context.Room, "RoomId", "RoomId");

            var reservation = new Reservation
            {
                ReservationFacilities = new List<ReservationFacility>()
            };

            // Populează AssignedFacilityDataList
            var facilitiesPageModel = new ReservationFacilitiesPageModel();
            facilitiesPageModel.PopulateAssignedFacilityData(_context, reservation);

            AssignedFacilityDataList = facilitiesPageModel.AssignedFacilityDataList;

            return Page();
        }


        [BindProperty]
        public Reservation Reservation { get; set; } = default!;

        public async Task<IActionResult> OnPostAsync(string[] selectedFacilities)
        {
            var newReservation = new Reservation();
            if (selectedFacilities != null)
            {
                newReservation.ReservationFacilities = new List<ReservationFacility>();
                foreach (var fac in selectedFacilities)
                {
                    var facToAdd = new ReservationFacility
                    {
                        FacilityId = int.Parse(fac)
                    };
                    newReservation.ReservationFacilities.Add(facToAdd);
                }
            }

            Reservation.ReservationFacilities = newReservation.ReservationFacilities;
            _context.Reservation.Add(Reservation);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
