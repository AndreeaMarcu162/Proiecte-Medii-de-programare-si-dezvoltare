﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Hotel.Data;
using Hotel.Models;

namespace Hotel.Pages.Reservations
{
    public class EditModel : ReservationFacilitiesPageModel
    {
        private readonly HotelContext _context;

        public EditModel(HotelContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Reservation Reservation { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Reservation = await _context.Reservation
                .Include(r => r.Room)
                .Include(r => r.Guest)
                .FirstOrDefaultAsync(m => m.ReservationId == id);

            if (Reservation == null)
            {
                return NotFound();
            }
            PopulateAssignedFacilityData(_context, Reservation);

            // Populează ViewData pentru RoomID (cu ID-ul și tipul camerei)
            ViewData["RoomID"] = new SelectList(
                _context.Room.Select(r => new
                {
                    r.RoomId,
                    Description = $"{r.RoomId} - {r.RoomType}" // ID-ul și tipul camerei
                }),
                "RoomId",
                "Description",
                Reservation.RoomId);

            // Populează ViewData pentru GuestID (nume complet al oaspeților)
            ViewData["GuestID"] = new SelectList(
                _context.Guest.Select(g => new
                {
                    g.GuestId,
                }),
                "GuestID",
                "FullName",
                Reservation.GuestId);

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id, string[] selectedFacilities)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reservationToUpdate = await _context.Reservation
                .Include(r => r.Room)
                .Include(r => r.Guest)
                .FirstOrDefaultAsync(r => r.ReservationId == id);

            if (reservationToUpdate == null)
            {
                return NotFound();
            }

            if (await TryUpdateModelAsync<Reservation>(
                reservationToUpdate,
                "Reservation",
                r => r.RoomId, r => r.GuestId,
                r => r.CheckInDate, r => r.CheckOutDate))
            {
                UpdateReservationFacilities(_context, selectedFacilities, reservationToUpdate);
                await _context.SaveChangesAsync();
                return RedirectToPage("./Index");
            }

            // Reîncarcă ViewData în caz de eroare
            ViewData["RoomID"] = new SelectList(
                _context.Room.Select(r => new
                {
                    r.RoomId,
                    Description = $"{r.RoomId} - {r.RoomType}"
                }),
                "RoomId",
                "Description",
                reservationToUpdate.RoomId);

            ViewData["GuestID"] = new SelectList(
                _context.Guest.Select(g => new
                {
                    g.GuestId,
                }),
                "GuestID",
                "FullName",
                reservationToUpdate.GuestId);

            UpdateReservationFacilities(_context, selectedFacilities, reservationToUpdate);
            PopulateAssignedFacilityData(_context, reservationToUpdate);
            return Page();
        }
    }
}
