﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Hotel.Data;
using Hotel.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Hotel.Pages.Reservations
{
    public class IndexModel : PageModel
    {
        private readonly Hotel.Data.HotelContext _context;

        public IndexModel(Hotel.Data.HotelContext context)
        {
            _context = context;
        }

        public ReservationData ReservationD { get; set; }
        public int ReservationId { get; set; }
        public string CurrentFilter { get; set; }
        public SelectList FacilitiesList { get; set; }
        public string SelectedFacility { get; set; }

        public async Task OnGetAsync(int? id, string searchString, string selectedFacility)
        {
            CurrentFilter = searchString;
            SelectedFacility = selectedFacility;

            ReservationD = new ReservationData();

            var reservations = _context.Reservation
                .Include(r => r.Guest)
                .Include(r => r.Room)
                .Include(r => r.ReservationFacilities)
                .ThenInclude(rf => rf.Facility)
                .AsQueryable();

            FacilitiesList = new SelectList(await _context.Facility.Select(f => f.FacilityName).ToListAsync());

            if (!string.IsNullOrEmpty(searchString))
            {
                reservations = reservations.Where(r =>
                r.Guest.FullName.Contains(searchString) ||
                r.Room.RoomType.Contains(searchString));
            }

            if (!string.IsNullOrEmpty(selectedFacility))
            {
                reservations = reservations.Where(r =>
                r.ReservationFacilities.Any(rf => rf.Facility.FacilityName == selectedFacility));
            }

            ReservationD.Reservations = await reservations.AsNoTracking().ToListAsync();
        }
    }
}
