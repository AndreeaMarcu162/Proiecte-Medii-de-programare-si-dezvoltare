﻿using System.ComponentModel.DataAnnotations;

namespace Hotel.Models
{
    public class Reservation
    {
        public int ReservationId { get; set; }
        public int RoomId { get; set; }
 
        public Room Room { get; set; }
        public int FacilityId { get; set; }

        public Facility Facility { get; set; }
        public int GuestId { get; set; }

        public Guest Guest { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Check In Date")]

        public DateTime CheckInDate { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "Check Out Date")]
        public DateTime CheckOutDate { get; set; }
        public ICollection<ReservationFacility>? ReservationFacilities { get; set; }
    }
}
