﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Hotel.Data;
using Hotel.Models;
using System.Collections.Generic;
using System.Linq;

namespace Hotel.Pages.Reservations
{
    public class ReservationFacilitiesPageModel : PageModel
    {
        public List<AssignedFacilityData> AssignedFacilityDataList;
        public void PopulateAssignedFacilityData(HotelContext context, Reservation reservation)
        {
            var allFacilities = context.Facility; 
            var reservationFacilities = new HashSet<int>(
                reservation.ReservationFacilities.Select(f => f.FacilityId)); 

            AssignedFacilityDataList = new List<AssignedFacilityData>();

            foreach (var fac in allFacilities)
            {
                AssignedFacilityDataList.Add(new AssignedFacilityData
                {
                    FacilityId = fac.FacilityId,
                    Name = fac.FacilityName, 
                    Assigned = reservationFacilities.Contains(fac.FacilityId) 
                });
            }
        }


        public void UpdateReservationFacilities(HotelContext context, string[] selectedFacilities, Reservation reservationToUpdate)
        {
            if (selectedFacilities == null)
            {
                reservationToUpdate.ReservationFacilities = new List<ReservationFacility>();
                return;
            }

            var selectedFacilitiesHS = new HashSet<string>(selectedFacilities);
            var reservationFacilities = new HashSet<int>
                (reservationToUpdate.ReservationFacilities.Select(f => f.FacilityId)); 

            foreach (var fac in context.Facility) 
            {
                if (selectedFacilitiesHS.Contains(fac.FacilityId.ToString()))
                {
                    if (!reservationFacilities.Contains(fac.FacilityId))
                    {
                        reservationToUpdate.ReservationFacilities.Add(new ReservationFacility
                        {
                            ReservationId = reservationToUpdate.ReservationId,
                            FacilityId = fac.FacilityId
                        });
                    }
                }
                else
                {
                    if (reservationFacilities.Contains(fac.FacilityId))
                    {
                        ReservationFacility reservationToRemove 
                            = reservationToUpdate
                            .ReservationFacilities
                            .SingleOrDefault(i => i.FacilityId == fac.FacilityId);
                        context.Remove(reservationToRemove);
                    }
                }
            }
        }
    }

    public class AssignedFacilityData
    {
        public int FacilityId { get; set; }
        public string Name { get; set; }
        public bool Assigned { get; set; }
    }
}