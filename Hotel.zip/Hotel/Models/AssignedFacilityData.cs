﻿namespace Hotel.Models
{
    public class AssignedFacilityData
    {
        public int FacilityId { get; set; }
        public string Name { get; set; }    
        public bool Assigned { get; set; }
    }
}
