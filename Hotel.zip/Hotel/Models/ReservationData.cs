﻿namespace Hotel.Models
{
    public class ReservationData
    {
        public IEnumerable<Reservation> Reservations { get; set; }
        public IEnumerable<Facility> Facilities { get; set; }
        public IEnumerable<ReservationFacility> ReservationsFacility { get; set; }
    }
}
