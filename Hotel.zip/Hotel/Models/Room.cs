﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hotel.Models
{
    public class Room
    {
        public int RoomId { get; set; }
        [Display(Name = "Room Type")]
        public string RoomType { get; set; }
        [Column(TypeName = "decimal(6, 2)")]
        public decimal Price { get; set; }
 
    }
}
