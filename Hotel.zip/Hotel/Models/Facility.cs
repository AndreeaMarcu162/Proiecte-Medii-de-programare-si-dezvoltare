﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hotel.Models
{
    public class Facility
    {
        public int FacilityId { get; set; }
        [Display(Name = "Facilities")]
        public string FacilityName { get; set; }
        [Column(TypeName = "decimal(6,2)")]
        public decimal Price { get; set; }
        public ICollection<ReservationFacility>? ReservationFacilities { get; set; }
    }
}
