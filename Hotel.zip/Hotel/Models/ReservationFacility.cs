﻿namespace Hotel.Models
{
    public class ReservationFacility
    {
        public int Id { get; set; }
        public int ReservationId { get; set; }
        public Reservation Reservation { get; set; }
        public int FacilityId { get; set; }
        public Facility Facility { get; set; }
    }
}
