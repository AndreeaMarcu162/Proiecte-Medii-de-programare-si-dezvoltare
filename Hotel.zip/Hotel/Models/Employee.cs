﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hotel.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        [Display(Name= "Full Name")]
        public string FullName { get; set; }
        public string Position { get; set; }
        [Column(TypeName = "decimal(6,2)")]
        public decimal Salary { get; set; }
    }
}
