﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Hotel.Migrations
{
    /// <inheritdoc />
    public partial class CreateReservationFacilitiesTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ReservationFacility_Facility_FacilityId",
                table: "ReservationFacility");

            migrationBuilder.DropForeignKey(
                name: "FK_ReservationFacility_Reservation_ReservationId",
                table: "ReservationFacility");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ReservationFacility",
                table: "ReservationFacility");

            migrationBuilder.RenameTable(
                name: "ReservationFacility",
                newName: "ReservationFacilities");

            migrationBuilder.RenameIndex(
                name: "IX_ReservationFacility_ReservationId",
                table: "ReservationFacilities",
                newName: "IX_ReservationFacilities_ReservationId");

            migrationBuilder.RenameIndex(
                name: "IX_ReservationFacility_FacilityId",
                table: "ReservationFacilities",
                newName: "IX_ReservationFacilities_FacilityId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ReservationFacilities",
                table: "ReservationFacilities",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ReservationFacilities_Facility_FacilityId",
                table: "ReservationFacilities",
                column: "FacilityId",
                principalTable: "Facility",
                principalColumn: "FacilityId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ReservationFacilities_Reservation_ReservationId",
                table: "ReservationFacilities",
                column: "ReservationId",
                principalTable: "Reservation",
                principalColumn: "ReservationId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ReservationFacilities_Facility_FacilityId",
                table: "ReservationFacilities");

            migrationBuilder.DropForeignKey(
                name: "FK_ReservationFacilities_Reservation_ReservationId",
                table: "ReservationFacilities");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ReservationFacilities",
                table: "ReservationFacilities");

            migrationBuilder.RenameTable(
                name: "ReservationFacilities",
                newName: "ReservationFacility");

            migrationBuilder.RenameIndex(
                name: "IX_ReservationFacilities_ReservationId",
                table: "ReservationFacility",
                newName: "IX_ReservationFacility_ReservationId");

            migrationBuilder.RenameIndex(
                name: "IX_ReservationFacilities_FacilityId",
                table: "ReservationFacility",
                newName: "IX_ReservationFacility_FacilityId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ReservationFacility",
                table: "ReservationFacility",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ReservationFacility_Facility_FacilityId",
                table: "ReservationFacility",
                column: "FacilityId",
                principalTable: "Facility",
                principalColumn: "FacilityId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ReservationFacility_Reservation_ReservationId",
                table: "ReservationFacility",
                column: "ReservationId",
                principalTable: "Reservation",
                principalColumn: "ReservationId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
