﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Hotel.Migrations
{
    /// <inheritdoc />
    public partial class RestrictCascadeBehavior : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ReservationFacilities_Facility_FacilityId",
                table: "ReservationFacilities");

            migrationBuilder.DropForeignKey(
                name: "FK_ReservationFacilities_Reservation_ReservationId",
                table: "ReservationFacilities");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ReservationFacilities",
                table: "ReservationFacilities");

            migrationBuilder.DropIndex(
                name: "IX_ReservationFacilities_ReservationId",
                table: "ReservationFacilities");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "ReservationFacilities",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .OldAnnotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ReservationFacilities",
                table: "ReservationFacilities",
                columns: new[] { "ReservationId", "FacilityId" });

            // Adaugă relația cu `Restrict` pentru FacilityId
            migrationBuilder.AddForeignKey(
                name: "FK_ReservationFacilities_Facility_FacilityId",
                table: "ReservationFacilities",
                column: "FacilityId",
                principalTable: "Facility",
                principalColumn: "FacilityId",
                onDelete: ReferentialAction.Restrict);

            // Adaugă relația cu `Restrict` pentru ReservationId
            migrationBuilder.AddForeignKey(
                name: "FK_ReservationFacilities_Reservation_ReservationId",
                table: "ReservationFacilities",
                column: "ReservationId",
                principalTable: "Reservation",
                principalColumn: "ReservationId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ReservationFacilities_Facility_FacilityId",
                table: "ReservationFacilities");

            migrationBuilder.DropForeignKey(
                name: "FK_ReservationFacilities_Reservation_ReservationId",
                table: "ReservationFacilities");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ReservationFacilities",
                table: "ReservationFacilities");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "ReservationFacilities",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ReservationFacilities",
                table: "ReservationFacilities",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_ReservationFacilities_ReservationId",
                table: "ReservationFacilities",
                column: "ReservationId");

            // Revine la `Cascade` pentru FacilityId
            migrationBuilder.AddForeignKey(
                name: "FK_ReservationFacilities_Facility_FacilityId",
                table: "ReservationFacilities",
                column: "FacilityId",
                principalTable: "Facility",
                principalColumn: "FacilityId",
                onDelete: ReferentialAction.Cascade);

            // Revine la `Cascade` pentru ReservationId
            migrationBuilder.AddForeignKey(
                name: "FK_ReservationFacilities_Reservation_ReservationId",
                table: "ReservationFacilities",
                column: "ReservationId",
                principalTable: "Reservation",
                principalColumn: "ReservationId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
