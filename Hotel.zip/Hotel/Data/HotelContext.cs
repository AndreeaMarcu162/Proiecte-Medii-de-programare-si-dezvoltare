﻿using Hotel.Models;
using Microsoft.EntityFrameworkCore;

public class HotelContext : DbContext
{
    public HotelContext(DbContextOptions<HotelContext> options)
        : base(options)
    {
    }

    public DbSet<Employee> Employee { get; set; }
    public DbSet<Facility> Facility { get; set; }
    public DbSet<Guest> Guest { get; set; }
    public DbSet<Reservation> Reservation { get; set; }
    public DbSet<Room> Room { get; set; }
    public DbSet<ReservationFacility> ReservationFacilities { get; set; }
}
